# IN - NOT IN - solution 1
SELECT

    *

FROM

    employees

WHERE

    first_name IN ('Denis' , 'Elvis');