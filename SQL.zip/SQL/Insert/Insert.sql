Insert into employees
(
	emp_no,
    birth_date,
    first_name,
    last_name,
    gender,
    hire_date
)Values
(
	999901,
    '1986-04-21',
    'John',
    'Smith',
    'M',
    '2011-01-01'
);
Select * from employees 
order by emp_no desc
limit 10;
-- Assignment 
SELECT

    *

FROM

    dept_emp

ORDER BY emp_no DESC

LIMIT 10;

insert into dept_emp

(

                emp_no,

    dept_no,

    from_date,

    to_date

)

values

(

                999903,

    'd005',

    '1997-10-01',

    '9999-01-01'

);
