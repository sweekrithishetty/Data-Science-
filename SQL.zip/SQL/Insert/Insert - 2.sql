Select * from departments
limit 10;
CREATE TABLE departments_dup (
    dept_no CHAR(4) NOT NULL,
    dept_name VARCHAR(40) NOT NULL
)	;
Select * from departments;
Select * from departments_dup
order by dept_no;
-- Assignment 
# Inserting Data INTO a New Table - solution

INSERT INTO departments VALUES ('d010', 'Business Analysis');
Select * from departments ;

