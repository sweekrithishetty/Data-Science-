# The commit statement 
-- Saves the transaction 
-- changes cannot be done
#The Rollback clause
-- allows you to take a step back
-- the last change will not be count
-- reverse to the last non-committed statement
Use employees;
SELECT 
    *
FROM
    employees
WHERE
    emp_no = 999901;
-- update statement after where condition
Select * from departments_dup;
order by dept_no;
Commit; -- save the dataset
UPDATE departments_dup 
SET 
    dept_no = 'd011',
    dept_name = 'Quality Control';
Rollback;
Commit;    
    

    
Update employees 
SET 
	first_name = 'Stella',
    last_name = 'Parinson',
    birth_date = '1990-12-31',
    gender = 'F'
where 
	emp_no = 999901;
# Assignment 
Update departments
SET
   dept_name = 'Data Analysis'
where 
     dept_name = 'Business Analysis';
     
Select * from departments

