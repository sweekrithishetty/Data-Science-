-- Aliases - rename selction from the query

SELECT 
    first_name, COUNT(first_name) as names_count
FROM
    employees
GROUP BY first_name
ORDER BY first_name DESC;
-- Aliases Assignments
Select salary, count(emp_no) as emps_with_same_salary from salaries
where salary > 80000
group by salary
order by salary;
-- Assignment 
Select emp_no , avg(salary) from salaries
group by emp_no
having avg(salary) > 120000
order by emp_no;
-- Assignment 



SELECT

*, AVG(salary)

FROM

salaries

WHERE

salary > 120000

GROUP BY emp_no

ORDER BY emp_no;
SELECT

*, AVG(salary)

FROM

salaries

GROUP BY emp_no

HAVING AVG(salary) > 120000;




