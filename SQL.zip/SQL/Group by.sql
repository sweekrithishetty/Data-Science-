-- Group by according to the specific fields
-- It must be placed after where condition and before order by clause
-- most powerful tool	
Select first_name from employees 
where first_name = 'Z%'
group by emp_no;
SELECT DISTINCT
    first_name
FROM
    employees;
-- Count number of times first_name occured 
SELECT 
    first_name, COUNT(first_name)
FROM
    employees
GROUP BY first_name
ORDER BY first_name DESC;




