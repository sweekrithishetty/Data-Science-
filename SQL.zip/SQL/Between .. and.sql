SELECT 
    *
FROM
    employees
WHERE
    hire_date between '1990-01-01' and '2000-01-01'; #both values will be included 
SELECT 
    *
FROM
    employees
WHERE
    hire_date not between '1990-01-01' and '2000-01-01'; # hire_date is before 1990-01-01 or is after '2000-01-01'
SELECT 
    *
FROM
    salaries
WHERE
    salary between '66000' and '70000'; 
SELECT 
    *
FROM
    salaries
WHERE
    emp_no not between '10004' and '10012'; 
SELECT 
    *
FROM
    departments
WHERE
    dept_no between 'd003' and 'd006'; 

