-- = ,>,>=,<,<> - different then ,!=
SELECT 
    *
FROM
    employees
WHERE
    hire_date >='2000-01-01';
-- Assignment 7
SELECT 
    *
FROM
    employees
WHERE
    hire_date >= '2000-01-01' AND gender = 'F';
Select * from salaries
where salary > 150000;

