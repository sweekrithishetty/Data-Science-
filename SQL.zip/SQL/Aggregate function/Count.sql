-- Count : applied to both numeric and non-numeric data
-- Count(distinct) : help us to encounter the number of times unique values are encountered in a given column
-- Count(*) : returns the number of all rows of the table, Null values included
SELECT 
    *
FROM
    salaries
ORDER BY salary DESC
-- 
LIMIT 10;
SELECT 
    COUNT(from_date)
FROM
    salaries; 
-- Count(distinct)
SELECT 
    COUNT(distinct from_date)
FROM
    salaries; 
SELECT 
    COUNT(*);
-- Assignment 
SELECT 
    COUNT(DISTINCT dept_no)
FROM
    dept_emp
