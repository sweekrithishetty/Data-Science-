-- * function doesn't work here
SELECT 
    SUM(salary)
FROM
    salaries;
-- Assignment 
SELECT 
    SUM(salary)
FROM
    salaries
WHERE
    from_date > 1997 - 01 - 01;
