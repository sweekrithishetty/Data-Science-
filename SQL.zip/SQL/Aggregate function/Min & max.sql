-- MIN and MAX
SELECT 
    MAX(salary)
FROM
    salaries;
SELECT 
    MIN(salary)
FROM
    salaries;
-- Assignment
SELECT 
    MIN(emp_no)
FROM
    employees;
SELECT 
    MAX(emp_no)
FROM
    employees;



