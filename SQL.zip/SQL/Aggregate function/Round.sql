-- Round
-- Round(no,decimal values)
SELECT 
    Round(AVG(salary))
FROM
    salaries;
-- Assignment 
SELECT 
    round( AVG(salary))
FROM
    salaries
where salary > 1997-01-01
