-- Coalesc for a single parameer
SELECT 
    dept_no,
    dept_name,
    IFNULL('department manager name') AS fake_col
FROM
    departments_dup
