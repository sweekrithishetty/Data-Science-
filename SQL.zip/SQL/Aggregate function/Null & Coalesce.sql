-- IF NULL(exp1,exp2) - cannot contain more then two parameters 
-- coalesce -- more than 
SELECT 
    dept_no,
    IFNULL(dept_name,
            'Department name not provided ') as dept_name
FROM
    departments_dup;
SELECT 
    dept_no,dept_name,
    coalesce(dept_manager,dept_name,'N/A') as dept_name
FROM
    departments_dup
order by dept_no asc;