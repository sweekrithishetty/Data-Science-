-- Average - Avg()
-- Aggregate functions can be applied to any group of column 
-- Count,sum,Min,Max,Avg : aggregate functions
-- frequently used together with group by class
SELECT 
    AVG(salary)
FROM
    salaries;
-- Assignment 
Select Avg(salary) from salaries
where from_date > 1997-01-01
