-- Order by
SELECT 
    *
FROM
    employees
ORDER BY first_name asc;
SELECT 
    *
FROM
    employees
ORDER BY first_name desc;
-- more then one instance
SELECT 
    *
FROM
    employees
ORDER BY first_name, last_name asc;
-- Assignment
SELECT 
    *
FROM
    employees
ORDER BY hire_date DESC;


