# Aggregate function
-- count() counts the number of non-null records in a field
-- sum() sums all the non-null values in a column
-- min() returns the minimum value from the entire list
-- max() returns the maximum value from the entire list
-- Avg() returns the average value from the entire list
SELECT 
    COUNT(first_name)
FROM
    employees;
-- with distinct
SELECT 
    COUNT(distinct first_name)
FROM
    employees;
-- Assignments 
SELECT 
    COUNT(salary)
FROM
    salaries
WHERE
    salary >= 100000;

SELECT 
    COUNT(*)
FROM
    dept_manager;