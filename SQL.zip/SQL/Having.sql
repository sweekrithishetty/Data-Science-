-- having should be inserted between group by and order by
select first_name , COUNT(first_name) as names_count
from employees
group by first_name  
having count(first_name) > 250
order by first_name;

Select emp_no from dept_emp
where from_date > '2000-01-01'
group by emp_no
having count(emp_no) > 1
order by emp_no