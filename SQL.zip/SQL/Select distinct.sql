Select gender from employees;
# Distinct - all distinct values 
Select distinct gender from employees;
# Assignment
SELECT DISTINCT
    hire_date
FROM
    employees;
 