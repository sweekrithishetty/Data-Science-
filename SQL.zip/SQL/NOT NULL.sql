-- Used to extract values that are not null - first_name i null or not
SELECT 
    *
FROM
    employees
WHERE
    first_name IS 	NULL; 
-- Assignment - 6 
SELECT 
    *
FROM
    departments
WHERE
    dept_no IS NOT NULL