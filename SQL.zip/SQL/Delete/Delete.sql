USE employees;
commit;
SELECT 
    *
FROM
    employees
WHERE
    emp_no = 10007	;
DELETE FROM employees 
WHERE
    emp_no = 10008;
Rollback;