-- Wildcard characters
-- % _ *
SELECT 
    *
FROM
    employees
WHERE
    first_name LIKE ('JACK%');
SELECT 
    *
FROM
    employees
WHERE
    first_name  LIKE ('JACK%');
