-- Precedence AND > OR
SELECT 
    *
FROM
    employees
WHERE
    last_name = 'Denis' AND ( gender = 'M' OR gender = 'F');
-- Assignment 5
SELECT 
    *
FROM
    employees
WHERE
    gender = 'F' AND (first_name = 'Kellie' OR first_name = 'Aruna');