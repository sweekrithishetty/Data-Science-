-- % - a substitute for a sequence of characters
-- _ - a particular character
SELECT 
    *
FROM
    employees
WHERE
    first_name LIKE ('ar%');
#2
SELECT 
    *
FROM
    employees
WHERE
    first_name NOT LIKE ('%ar');
#3
SELECT 
    *
FROM
    employees
WHERE
    first_name LIKE ('%Mar%');
SELECT 
    *
FROM
    employees
WHERE
    first_name LIKE ('Mar_');
-- Asssignment - 6
SELECT 
    *
FROM
    employees
WHERE
    first_name LIKE ('Mark%');
SELECT 
    *
FROM
    employees
WHERE
    hire_date like('%2000%');
SELECT 
    *
FROM
    employees
WHERE
    emp_no like('%1000_%') 

    