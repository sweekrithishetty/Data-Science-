Select * from salaries
order by salary desc
limit 10;
Select * from salaries
order by emp_no desc
limit 10;
-- Assignment
Select * from dept_emp
limit 100;