-- Aliases - rename selction from the query

SELECT 
    first_name, COUNT(first_name) as names_count
FROM
    employees
GROUP BY first_name
ORDER BY first_name DESC;
-- Aliases Assignments
Select salary, count(emp_no) as emps_with_same_salary from salaries
where salary > 80000
group by salary
order by salary;


