-- equal operators that can be used with Where clause
-- AND -- IN -- NOT IN       --EXISTS NOT EXISTS
-- OR -- LIKE -- NOT LIKE    -- IS NULL NOT NULL
-- BETWEEN.. --AND..         -- COMPARISON OPERATORS ,etc
-- AND : Alows to logically combine two statements
SELECT 
    *
FROM
    employees
WHERE
    first_name = 'Denis' AND gender = 'M';
-- Assignment 3
SELECT 
    *
FROM
    employees
WHERE
    first_name = 'Kellie' AND gender = 'F'

