SELECT 
    first_name, last_name
FROM
    employees;
Select * from employees;
-- Add seperator
-- * all 
SELECT 
    dept_no
FROM
    departments;
SELECT 
    *
FROM
    departments;