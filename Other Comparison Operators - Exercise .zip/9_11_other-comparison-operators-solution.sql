# Other comparison operators - solution


SELECT

    *

FROM

    employees

WHERE

    hire_date >= '2000-01-01'

        AND gender = 'F';

SELECT

    *

FROM

    salaries

WHERE

    salary > 150000;