# The UPDATE Statement – Part II - solution

UPDATE departments

SET

    dept_name = 'Data Analysis'

WHERE

    dept_no = 'd010';